#ifndef __MYDELAY_H__
#define __MYDELAY_H__

//Delay =========================================================
void delay(unsigned int k);
void us_delay(unsigned int us_time);
void ms_delay(unsigned int ms_time);

#endif
