/*
 * File: CAN_NODE_2_AUTO_types.h
 *
 * Real-Time Workshop code generated for Simulink model CAN_NODE_2_AUTO.
 *
 * Model version                        : 1.27
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Mon Dec 14 21:43:37 2020
 * TLC version                          : 7.5 (Jan 19 2010)
 * C/C++ source code generated on       : Mon Dec 14 21:43:38 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_CAN_NODE_2_AUTO_types_h_
#define RTW_HEADER_CAN_NODE_2_AUTO_types_h_

/* Forward declaration for rtModel */
typedef struct RT_MODEL_CAN_NODE_2_AUTO RT_MODEL_CAN_NODE_2_AUTO;

#endif                                 /* RTW_HEADER_CAN_NODE_2_AUTO_types_h_ */

/*
 * File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
